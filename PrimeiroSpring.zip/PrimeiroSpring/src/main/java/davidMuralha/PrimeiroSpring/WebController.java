package davidMuralha.PrimeiroSpring;

import davidMuralha.ConectarBanco.ConectarBanco;
import java.sql.Connection;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import davidMuralha.Mongo.ConectaMongo;

@Controller
public class WebController {
    @RequestMapping("/form")
    public String DigaOla2(Model modelo) {
        System.out.println("Estou no form");
        modelo.addAttribute("mensagem2","Formulário!");
        return "form";
    } 
    
    @RequestMapping(value = "/respostaForm", method = RequestMethod.POST)
    public String DigaOla3(Model modelo, String fname, String email, int code, String prof, boolean trab) {
        System.out.println("Agora estou no Resposta Form");
        modelo.addAttribute("mensagem3","Resposta do Formulário:\n" + fname + " seja bem vindo\n" + "seu email é: " + email+" - Seu id ="+code);
        ConectaMongo con = new ConectaMongo();
        con.insertValues(fname, prof, code, trab);
        con.getValues();
        ConectarBanco obj = new ConectarBanco();
        Connection conexao = obj.connectionMySql();
        obj.dataBaseInsert(fname, email);
        obj.consulta(conexao);
        obj.closeConnectionMySql(conexao);
        return "respostaForm";
    } 
    
    
}